# wechat-longhu
微信小程序——全栈小案例：销售龙虎榜

### 说明：

源码来自：https://github.com/getweapp/weapp-longhubang

``` bash
# 在server目录下的server.js文件中配置mongodb数据库连接地址

# 在server目录下安装相关依赖
npm install

# 在server目录下运行服务器
node server

# 在client目录下用微信开发者工具跑起来
```
