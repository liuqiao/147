'use strict';

module.exports = function(Adminuser) {

};
