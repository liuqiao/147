'use strict';

module.exports = function(Astoken) {

};
