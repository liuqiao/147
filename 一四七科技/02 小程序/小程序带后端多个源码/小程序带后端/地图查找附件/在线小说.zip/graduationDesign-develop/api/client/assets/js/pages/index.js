// var API_URL = 'http://api.andylistudio.com/api';
var API_URL = 'http://localhost:3000/api';

localStorage.setItem('API_URL', API_URL);