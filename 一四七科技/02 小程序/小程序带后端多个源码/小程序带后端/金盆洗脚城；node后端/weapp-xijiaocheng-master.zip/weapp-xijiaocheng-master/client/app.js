/*
* 作者： 刘焱旺 yw@getweapp.com
* 答疑交流QQ群：499859691
*/


App({
  onLaunch: function () {

  },
  onShow: function () {

  },
  onHide: function () {

  }
})
