# 微信小程序－GetWeApp金盆洗脚城［全栈］

### 说明：

实现了用户登录，支付等功能，特色：
- 全栈

### 数据接口:

- 自己服务器接口

### 目录结构：

客户端：
- images — 存放项目图片文件
- pages — 存放项目页面渲染相关文件
- utils — 存放js库和数字格式化文件

服务端：
- server.js

### 开发环境：

微信web开发者工具 v0.11.122100
node

### 项目截图：

https://www.getweapp.com/project?projectId=5883a2f152e1e8733dc567e0

### 作者的设计思路和源码分析视频课程：

https://www.getweapp.com/videoCourse?courseId=588420e745b89c334dd2754c
