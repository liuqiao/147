# 阴阳师妖怪搜索小程序 

### 名称：式神猎手

使用：微信－小程序－搜索－式神猎手

或扫描二维码： 

![](https://github.com/bluedazzle/hellspawn-hunter-weapp/blob/master/static/image/display/ssqrcode.jpg)

![](https://github.com/bluedazzle/hellspawn-hunter-weapp/blob/master/static/image/display/pre.png) 

## 效果图： 

![](https://github.com/bluedazzle/hellspawn-hunter-weapp/blob/master/static/image/display/play.gif) 

## 功能特点：

1. 单字搜索式神或神秘线索；
2. 最近热搜妖怪；
3. 个人搜索历史；
4. 反馈功能；

#License

Copyright © RaPoSpectre.

All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.
Redistributions in binary form must reproduce the above copyright notice, this
list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
