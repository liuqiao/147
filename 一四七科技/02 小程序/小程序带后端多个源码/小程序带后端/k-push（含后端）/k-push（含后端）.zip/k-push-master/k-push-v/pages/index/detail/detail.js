//index.js
Page({
    data: {
    item: {
      title:'',
      auth: '',
      time: '',
      image_url:'',
      content:''
    }
    },
    getDetail: function(id) {
        var that = this;
        wx.request({
            url: 'http://localhost:3000/lists/getDetail?id='+id,
            data: {},
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                that.setData({
                    item: res.data[0]
                })

                console.log(res);
            }
        })
    },
    onLoad: function(option) {
        console.log('onLoad')
        var that = this;
        var currentId =option.id ;
        //调用应用实例的方法获取全局数据
        // that.setData({
        //     currentId: option.id
        // });
        that.getDetail(currentId)


    }
})
