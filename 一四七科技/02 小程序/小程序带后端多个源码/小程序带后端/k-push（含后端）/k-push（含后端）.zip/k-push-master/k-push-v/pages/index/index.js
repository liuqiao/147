//index.js
Page({
    data: {
        pushList: []
    },
    getPustList: function() {
      var that = this;
        wx.request({
            url:'http://localhost:3000/lists/getPushList',
            data: {},
            header: {
                'content-type': 'application/json'
            },
            success: function(res) {
                that.setData({
                    pushList: res.data
                })

                console.log(res);
            }
        })
    },
    toDetailPage:function(e){
        var id=e.currentTarget.id
        wx.navigateTo( {
            url:'../index/detail/detail?id='+id
        }
    );
    },
    onLoad: function() {
        console.log('onLoad')
        var that = this;
        //调用应用实例的方法获取全局数据
        that.getPustList();

    }
})
