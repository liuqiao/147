var express = require('express');
var fs = require("fs");
var router = express.Router();
var mysql = require('../mysql/mysql')
var reptile = require('../reptile/reptile')

// get接口
router.get('/getPushList', function(req, res, next) {
    var sql = 'select * from push_article'
    mysql.query(sql).then(function(data) {
        console.log('data' + data)
        res.send(data);
    }).then(function(err) {
        res.send('error');
    });

});
router.get('/getPushDetail', function(req, res, next) {
    var id = req.query.id;
    var sql = 'select * from push_article where id = ' + id
    mysql.query(sql).then(function(detail) {
        console.log('detail' + detail)
        res.send(detail);
    }).then(function(err) {
        res.send('error');
    });

});
// 调用爬虫、存储
router.get('/crawlDatas', function(req, res, next) {
    reptile.getList().then(function(resolve) {
        console.log('抓取的结果' + resolve)
        res.send('200,抓取成功');
    }).then(function(err) {
        res.send('error');
    });
})
module.exports = router;
