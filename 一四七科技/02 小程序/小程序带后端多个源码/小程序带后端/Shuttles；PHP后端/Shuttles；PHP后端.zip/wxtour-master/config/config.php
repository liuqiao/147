<?php
define(SQL_IP, "localhost");
define(SQL_USER, "root");
define(SQL_PASSWD, "");
?>
