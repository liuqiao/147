module.exports = {
  image: {
      record: "/images/recorder.png",
      recording: "/images/recorder.gif",
      play: "/images/play.png",
      playing: "/images/play.gif"
  },
}
