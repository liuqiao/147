<?php

ini_set('date.timezone','Asia/Shanghai');
