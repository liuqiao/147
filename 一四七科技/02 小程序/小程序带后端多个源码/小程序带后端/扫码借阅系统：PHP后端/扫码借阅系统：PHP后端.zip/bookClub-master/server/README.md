# book club server 

## quick start

1. composer install
2. cd config
3. rename database.php.sample as 'database.php'

