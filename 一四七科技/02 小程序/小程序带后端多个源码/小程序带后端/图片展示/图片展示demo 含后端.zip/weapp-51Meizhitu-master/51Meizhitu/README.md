# 微信小程序示例-BeautifulGirl
  微信小程序的一个样例，也可以说是一个福利型的小程序，主要功能是展示美女模特图片，目前的版本包括3个页面：<br> 
  1.首页：相册列表页面，按照类别显示美女图片的列表<br> 
  2.图片列表页：用swiper展示一个相册下的所有图片<br> 
  3.相册类别编辑页面<br> 
  Wechat APP Sample: An app shows pictures of beautiful girls
# 预览
## 首页-相册列表页面
![](https://raw.githubusercontent.com/liumulin614/fe-demo/master/bed/preview/%E9%A6%96%E9%A1%B5.png) 
## 图片列表展示页
![](https://raw.githubusercontent.com/liumulin614/fe-demo/master/bed/preview/2.png) 
## 相册类别编辑页
![](https://raw.githubusercontent.com/liumulin614/fe-demo/master/bed/preview/3.png) 
